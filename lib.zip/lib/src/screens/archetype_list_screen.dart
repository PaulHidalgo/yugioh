import 'package:flutter/material.dart';
import '../providers/archetype_provider.dart';
import 'monster_detail_screen.dart';
import 'package:provider/provider.dart';

class ArchetypeListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final archetypes = Provider.of<ArchetypeProvider>(context).archetypes;

    return Scaffold(
      appBar: AppBar(title: Text('Archetypes')),
      body: ListView.builder(
        itemCount: archetypes.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(archetypes[index].name),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MonsterDetailScreen(
                    archetypeName: archetypes[index].name,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
